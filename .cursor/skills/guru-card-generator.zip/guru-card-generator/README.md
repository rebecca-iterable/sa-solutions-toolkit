# Guru Card Generator — SA Team Guide

Turn customer-specific solution docs into generalized [Customer Solutions Knowledge Base (CSKB)](https://app.getguru.com/collections/a9n8p/Customer-Solutions-Knowledge-Base) cards using Cursor.

---

## Slack blurb (copy-paste)

```
:new: Guru Card Generator in Cursor — turn solution docs into CSKB cards faster

Clone sa-solutions-toolkit, connect Guru MCP, and ask Cursor to generalize a solutions doc. It will:
• Anonymize customer details
• Map content to our Guru template (Purpose, Problem, Solution, etc.)
• Save screenshots to examples/<pattern>/images/ with borders applied
• Create a WIP: draft in Guru via MCP

You finish: CSKB collection + folder, upload bordered images, tags, verifier, publish (~5–10 min vs writing from scratch).

Setup (one time):
1. Clone repo + open in Cursor
2. Add Guru MCP to ~/.cursor/mcp.json → { "mcpServers": { "Guru": { "url": "https://mcp.api.getguru.com/mcp" } } }
3. Restart Cursor, authenticate Guru
4. pip install pillow (for image borders)

Prompt: "Generalize this solutions doc and create a Guru draft in CSKB."

Input: paste text, upload PDF/DOCX, or point to a local file. Google Doc links alone won't work — export or paste content.

Reference example: .cursor/skills/guru-card-generator/examples/statsig-journey-live-data/
Full guide: .cursor/skills/guru-card-generator/README.md
```

---

## What it does

| Automated | Manual (in Guru) |
|-----------|------------------|
| Anonymize customer names, IDs, metrics | Move draft to **Customer Solutions Knowledge Base** |
| Generalize deal language → reusable guidance | Choose folder, tags (max 4), verifier |
| Map to CSKB template sections | Paste into template fields if styles are flat |
| Border screenshots (`*-bordered.png`) | Upload bordered images |
| Save local files under `examples/<pattern>/` | Remove `WIP:` from title and publish |
| Create Guru draft via MCP | — |

## One-time setup

1. **Clone and open** `sa-solutions-toolkit` in Cursor
2. **Connect Guru MCP** — add to `~/.cursor/mcp.json`:

   ```json
   {
     "mcpServers": {
       "Guru": { "url": "https://mcp.api.getguru.com/mcp" }
     }
   }
   ```

   Restart Cursor and authenticate when prompted.

3. **Install Pillow** (image borders):

   ```bash
   pip install pillow
   ```

4. **Skim the reference example** — [examples/statsig-journey-live-data/](examples/statsig-journey-live-data/) shows before/after quality for one Journey pattern. Other Iterable features (campaigns, catalog, data feeds, etc.) follow the same workflow.

## How to use

### Prompts that work

- *"Generalize this solutions doc and create a Guru draft in CSKB."*
- *"Turn this into a Guru card for the Customer Solutions Knowledge Base."*
- *"Anonymize this and post a Guru draft."*

To skip Guru MCP: *"Generalize only — don't create a Guru draft yet."*

### Input formats

| Works | Doesn't work alone |
|-------|-------------------|
| Pasted text / markdown | Google Doc share link |
| Uploaded PDF or DOCX | — |
| Local file path in repo | — |
| Google Doc export (PDF/DOCX) | — |

If the doc has UI walkthrough steps but no screenshots, Cursor will ask you to upload them.

### Writing new solution docs

Use [docs/solution-template.md](../../../docs/solution-template.md) as the input structure — it maps cleanly to the Guru card template.

## After Cursor creates the draft

1. Open the draft from **My Drafts** in Guru
2. Set collection → **Customer Solutions Knowledge Base**
3. Choose the correct folder
4. Paste content **section by section** into template fields (don't bulk-paste — preserves heading styles)
5. Upload images from `examples/<pattern>/images/*-bordered.png`
6. Add tags, set verifier, remove `WIP:` from title, publish

**Redact secrets** in screenshots (API keys, account IDs) before uploading.

## Screenshots and images

When UI walkthrough content is detected, Cursor will:

1. Ask for screenshots (journey canvas, webhook config, etc.)
2. Save originals to `examples/<pattern-slug>/images/`
3. Run `python scripts/add-image-borders.py examples/<pattern-slug>/images/`
4. Embed `*-bordered.png` in the local markdown

Guru cannot add borders in the editor — always upload the bordered copies.

## Title format

`[Pattern name]: [Iterable capability] + [Integration/partner if any]`

Examples:
- Real-time Experiment Assignment: Journey Live Data + Statsig
- Catalog-Based Product Recommendations: Data Feeds + Shopify
- Post-Purchase Cross-Sell: Triggered Campaign + Segment

## Contribute examples

When you document a new pattern, keep the generated files:

```
examples/your-pattern-name/
  input-solution-doc.md
  output-guru-card.md
  images/          # originals + *-bordered.png
```

See [examples/README.md](examples/README.md).

## More detail

- Skill workflow: [SKILL.md](SKILL.md)
- Guru template sections: [guru-template.md](guru-template.md)
- MCP publish config: [guru-config.md](guru-config.md)
- CSKB style guide: [Writing a Knowledge Base Card](https://app.getguru.com/card/TnA5dkRc/Writing-a-Knowledge-Base-Card)
